import json
from json import JSONEncoder
import numpy
import pygame
import pygame as pg
from Hero import Hero
from henloEngine import GameMap, GameObject, UpdatableObjectInterface

maze_path = 'C:/Education/MiniGame/Maze/Random/random.json'


class NumpyArrayEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, numpy.ndarray):
            return obj.tolist()
        return JSONEncoder.default(self, obj)


class MazeCamera(GameObject, UpdatableObjectInterface):
    def __init__(self):
        super(MazeCamera, self).__init__(0, 0, 0)
        self.__camera_lock_object = None
        self.__objects = []
        self.mazeSurface = pygame.Surface((560, 560))

    def append_game_object(self, obj: GameObject, to_sort=True, is_camera_lock=False):
        self.__objects.append(obj)
        if to_sort:
            self.__objects.sort(key=lambda o: o.z, reverse=False)
        if is_camera_lock and isinstance(obj, GameObject):
            self.__camera_lock_object = obj

    def update(self, time: float):
        for obj in self.__objects:
            if isinstance(obj, UpdatableObjectInterface):
                obj.update(time)

    def draw(self):
        self.mazeSurface.fill((0, 0, 0))
        # tmp = (280 - self.__camera_lock_object.x, 280 - self.__camera_lock_object.y)
        tmp = (280 - self.__camera_lock_object.x - 40, 280 - self.__camera_lock_object.y - 40)
        for obj in self.__objects:
            obj.update_position(tmp[0], tmp[1])
            if obj == self.__camera_lock_object:
                obj.set_position(obj.x, obj.y)
            obj.draw()
            obj.update_position(-tmp[0], -tmp[1])
            if obj == self.__camera_lock_object:
                obj.set_position(obj.x, obj.y)
        self.window.blit(self.mazeSurface, (0, 0))
        pass

    def set_window(self, surface: pg.Surface):
        super(MazeCamera, self).set_window(surface)
        for obj in self.__objects:
            obj.set_window(self.mazeSurface)


class Maze(object):
    """

    """

    def __init__(self):
        self.maze = []
        self.mazeDrawer = GameMap()
        self.myHero = Hero(x=1, y=1)
        self.myCamera = MazeCamera()

    def initialize(self):
        self.mazeDrawer.load_maze(self.maze)
        self.myCamera.append_game_object(self.mazeDrawer)
        self.myCamera.append_game_object(self.myHero.heroDrawer, True, True)

    def maze_save(self, maze_random_value):
        print("all right")

        with open(maze_path, 'r') as f:
            template = json.load(f)
            template["Maze_random"] = maze_random_value

        with open(maze_path, 'w') as ff:

            ff.seek(0)
            ff.write(json.dumps(template, cls=NumpyArrayEncoder, indent=4, sort_keys=True))
        self.maze = maze_random_value

    def hero_interaction(self, key):  # todo ТОЛЬКО логика взаимодейтсвия
        """Логика взаимодейтсвия героя с объектами в лабиринте"""
        if self.myHero.can_move():
            if key == pg.K_d:
                if self.maze[self.myHero.y][self.myHero.x + 1] != 1:
                    self.myHero.move_position(dx=1, dy=0)
            if key == pg.K_a:
                if self.maze[self.myHero.y][self.myHero.x - 1] != 1:
                    self.myHero.move_position(dx=-1, dy=0)
            if key == pg.K_s:
                if self.maze[self.myHero.y + 1][self.myHero.x] != 1:
                    self.myHero.move_position(dx=0, dy=1)
            if key == pg.K_w:
                if self.maze[self.myHero.y - 1][self.myHero.x] != 1:
                    self.myHero.move_position(dx=0, dy=-1)

















