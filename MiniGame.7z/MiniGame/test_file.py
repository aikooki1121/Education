import pygame as pg

print(pg.image.get_extended())