import pygame as pg
from abc import abstractmethod

sprites_folder = 'v1.1 dungeon crawler 16x16 pixel pack'

class GameObject:
    window = None

    def __init__(self, x=0, y=0, z=0):
        self.x = x
        self.y = y
        self.z = z

    def set_window(self, surface: pg.Surface):
        self.window = surface

    def update_position(self, dx, dy):
        self.x += dx
        self.y += dy

    @abstractmethod
    def draw(self):
        pass


class UpdatableObjectInterface(object):
    @abstractmethod
    def update(self, time: float):
        pass


class KeyboardInterface(object):
    def key_up(self, key):
        pass

    def key_down(self, key):
        pass


class UpdatableObject(GameObject, UpdatableObjectInterface):
    def __init__(self):
        super().__init__()

    def draw(self):
        pass

    def update(self, time: float):
        pass


class PlayerObject(UpdatableObject, KeyboardInterface):
    def __init__(self):
        super().__init__()
        self.orientation = "right"
        self.animating = False
        self.color = (255, 255, 255)
        self.radius = 10
        self.herodraw = MobSprite(x_sprite=self.x, y_sprite=self.y,
                                  filename=sprites_folder + '/heroes/knight/knight_{anim_type}_anim_f{frame_num}.png',
                                  anim_names=['idle', 'run'])
        self.anim_vector_x = 0.0
        self.anim_vector_y = 0.0
        self.xf = 0.0
        self.yf = 0.0
        self.anim_timer = 0.0
        self.move_anim_time = 0.3
        self.idle_anim_time = 0.6

    def move_to_new_position(self, x, y):
        if abs(x - self.x) > 10:
            self.orientation = 'right' if x - self.x > 10 else 'left'
        self.herodraw.starting_anim('run')
        self.animating = True
        self.anim_timer = 0.0
        self.xf = float(self.x)
        self.yf = float(self.y)
        self.anim_vector_x = (x - self.x) / self.move_anim_time
        self.anim_vector_y = (y - self.y) / self.move_anim_time
        self.set_position(self.x, self.y)

    def update(self, time: float):
        self.anim_timer += time
        if self.animating:
            if self.anim_timer >= self.move_anim_time:
                self.anim_timer = 0.0
                self.animating = False
                self.herodraw.starting_anim('idle')
            else:
                self.herodraw.current_anim_frame = int(self.anim_timer / (self.move_anim_time / self.herodraw.CONST_ANIM_COUNT))
                self.xf += self.anim_vector_x * time
                self.yf += self.anim_vector_y * time
                self.set_position(int(self.xf), int(self.yf))
        else:  # for idle animation
            if self.anim_timer >= self.idle_anim_time:
                self.anim_timer = 0.0
            self.herodraw.current_anim_frame = int(self.anim_timer / (self.idle_anim_time / self.herodraw.CONST_ANIM_COUNT))

    def set_position(self, x, y):
        self.x = x
        self.y = y
        self.herodraw.rect.x = self.x
        self.herodraw.rect.y = self.y

    def move_position(self, dx, dy):
        self.x += dx
        self.y += dy

    def draw(self):
        if self.orientation == "right":
            self.window.blit(self.herodraw.get_current_image(), self.herodraw.rect)
        elif self.orientation == "left":
            self.window.blit(pg.transform.flip(self.herodraw.get_current_image(), True, False), self.herodraw.rect)
        # self.window.blit(self.herodraw.image, self.herodraw.rect)
        # temp_surf = self.window.copy()
        # self.window.fill((0, 0, 0))
        # pg.draw.circle(self.window, self.color, (self.x, self.y), self.radius)

        # self.window.blit(temp_surf, (-self.herodraw.rect.x+240, -self.herodraw.rect.y+240))


class MapTileSprite(pg.sprite.Sprite):
    def __init__(self, path: str, scale: int):
        pg.sprite.Sprite.__init__(self)
        tmp_img = pg.image.load(path)
        self.image = pg.transform.scale(tmp_img.convert_alpha(), (tmp_img.convert_alpha().get_width() * scale,
                                                                  tmp_img.convert_alpha().get_height() * scale))

    def set_image_rect(self, x, y):
        self.rect = self.image.get_rect(center=(x, y))


class MapTile(GameObject):
    width = height = 80  # default size of tile

    def __init__(self, a_id, a_type, a_sprite: MapTileSprite):
        GameObject.__init__(self)
        self.tileId = a_id
        self.tileType = a_type
        self.tileImg = a_sprite

    def set_coord(self, x, y):
        self.x = x * self.width
        self.y = y * self.height
        self.tileImg.set_image_rect(self.x + self.width / 2, self.y + self.height / 2)

    def update_position(self, dx, dy):
        GameObject.update_position(self, dx, dy)
        self.tileImg.set_image_rect(self.x + self.width / 2, self.y + self.height / 2)

    def draw(self):
        self.window.blit(self.tileImg.image, self.tileImg.rect)


class GameMap(GameObject):

    def __init__(self):
        super().__init__()
        self.tilesMap = []
        self.tilesTypeSprite = {}

    def set_window(self, surface: pg.Surface):
        for a in self.tilesMap:
            a.set_window(surface)
        super().set_window(surface)

    def get_tile_sprite(self, a_type):
        if not (a_type in self.tilesTypeSprite):
            tile_path = ''
            if a_type == 1:
                tile_path = '/tiles/wall/wall_1.png'
            elif a_type == 2:
                tile_path = '/tiles/floor/floor_side.png'
            self.tilesTypeSprite[a_type] = MapTileSprite(sprites_folder + tile_path, 5)
        return self.tilesTypeSprite[a_type]

    def load_maze(self, game_map):
        i = 0
        ix = iy = 0
        self.tilesMap.clear()
        for a in game_map:
            ix = 0
            for tile_type in a:
                tmp_tile = MapTile(i, tile_type, self.get_tile_sprite(tile_type))
                tmp_tile.set_coord(ix, iy)
                self.tilesMap.append(tmp_tile)
                i += 1
                ix += 1
            iy += 1

    def draw(self):  # todo отрисовка карты, старый вариант
        for tile in self.tilesMap:
            tile.update_position(self.x, self.y)
            tile.draw()
            tile.update_position(-self.x, -self.y)


class Game:
    objects = []  # list of  'GameObject's
    keyboardListeners = []

    def __init__(self):
        self.objects.clear()
        self.keyboardListeners.clear()
        pass


class MobSprite(pg.sprite.Sprite):  # todo класс отрисовки спрайтов
    CONST_ANIM_COUNT = 6

    def __init__(self, x_sprite: int, y_sprite: int, filename, anim_names):
        pg.sprite.Sprite.__init__(self)
        self.current_anim = anim_names[0]
        self.current_anim_frame = 0
        self.images = {}
        for anim in anim_names:
            frames = []
            for i in range(self.CONST_ANIM_COUNT):
                tmp_image = pg.image.load(filename.format(anim_type=anim, frame_num=i))
                frames.append(pg.transform.scale(tmp_image.convert_alpha(), (
                    tmp_image.convert_alpha().get_width() * 5, tmp_image.convert_alpha().get_height() * 5)))
            self.images[anim] = frames

        # self.image = pg.transform.scale(tmp_image.convert_alpha(), (tmp_image.convert_alpha().get_width()*5, tmp_image.convert_alpha().get_height()*5))
        # print(self.image.get_height(), self.image.get_width())
        self.rect = self.get_current_image().get_rect(center=(x_sprite, y_sprite))

    def get_current_image(self):
        return self.images[self.current_anim][self.current_anim_frame]

    def starting_anim(self, anim_name):
        self.current_anim = anim_name
        self.current_anim_frame = 0

    # def update(self):  # todo изменить движение спрайта
    #     if self.rect.y < H:
    #         self.rect.y += 2
    #     else:
    #         self.rect.y = 0


class Engine(object):
    __GAME_WIN_WIDTH = 560
    __GAME_WIN_HEIGHT = 560
    __FPS = 60

    def __init__(self, game_width=960, game_height=560):
        pg.init()
        self.__GAME_WIN_WIDTH = game_width
        self.__GAME_WIN_HEIGHT = game_height
        self.win = pg.display.set_mode((self.__GAME_WIN_WIDTH, self.__GAME_WIN_HEIGHT))
        pg.display.set_caption("Название игры")
        self.framePerSec = pg.time.Clock()

        self.game_client = Game()
        self.game_client.objects.clear()

    def start_game(self):
        run = True
        while (run):
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    run = False
                if event.type == pg.KEYDOWN:
                    for obj in self.game_client.keyboardListeners:
                        if isinstance(obj, KeyboardInterface):
                            obj.key_down(event.key)
                if event.type == pg.KEYUP:
                    for obj in self.game_client.keyboardListeners:
                        if isinstance(obj, KeyboardInterface):
                            obj.key_up(event.key)
                # key up keyboard

            self.win.fill((0, 0, 0))

            for obj in self.game_client.objects:
                if isinstance(obj, UpdatableObjectInterface):
                    obj.update(self.framePerSec.get_time() / 1000.0)
            for obj in self.game_client.objects:
                if isinstance(obj, GameObject):
                    obj.draw()

            pg.display.update()
            self.framePerSec.tick(self.__FPS)

        pg.quit()

    def append_game_object(self, obj: GameObject, set_win=False, to_sort=True):
        if set_win:
            obj.set_window(self.win)
        self.game_client.objects.append(obj)
        if to_sort:
            self.game_client.objects.sort(key=lambda o: o.z, reverse=False)

    def append_keyboard_listener(self, obj: KeyboardInterface):
        self.game_client.keyboardListeners.append(obj)
