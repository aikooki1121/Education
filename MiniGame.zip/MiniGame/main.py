from Game_Scene import GameScene

start = GameScene()
start.load()
start.inition()
start.run_game()
